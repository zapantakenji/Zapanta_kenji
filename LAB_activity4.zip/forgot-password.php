<?php
$conn = mysqli_connect('localhost','root',"",'registered_user');
if(isset($_POST['submit'])){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $query = "select * from users where email='$email'";
    $run = mysqli_query($conn,$query);
    if(mysqli_num_rows($run)>0){

        $row = mysqli_fetch_array($run);
        $db_email = $row['email'];
        $db_id = $row['id'];
        $token = uniqid(md5(time));//this is a random token.
        $query = "INSERT INTO password_reset (id,email,token) VALUES(NULL,'$email','token')";
        if(mysqli_query($conn, $query)){
            $to = $db_email;
            $subject = "Password reset link";
            $message="Click <a href='https://YOUR_WEBSITE.com/reset.php?token=$token'>here</a> to reset your password";
            $headers = "MIME-Version:1.0"."\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8"."\r\n";
            $headers .= 'From:<demo@demo.com>'."\r\n";
            //mail($to, $subject,$message,$headers);
            $msg = "<div class='alert alert-success'>Password reset link has been sent to the email.</div>";
        }
    }else{
        $msg = "<div class='alert alert-danger'>User not found.</div>";
    

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" 
    integrity=sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u
    crossorigin="anonymous">
    <link rel="stylesheet" href="/css/main.css">
</head>
<body>

<div class="container">
    <div class="row">
    <div class="col-md-6 col-md-offset-3">
    <h1>Forgot Password</h1><hr>
    <form action="" method="post">
    <div class="form-group">
    <label for="">Enter Email</label>
    <input type="email" name="email" class="form-control">
    </div>
    <?php if(isset($msg)){echo $msg;}?>
    <div class="form-group">
    <button name="submit" class="btn btn-primary btn-block">Submit</button>
    </div>
   
    </form>
    </div>
    </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7I2mCWNIpG9mGNIcPD7Txa"
        crossorigin="anonymous"></script>
</div>
</body>
</html>