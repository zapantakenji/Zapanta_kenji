<?php
$conn = mysqli_connect('localhost','root',"",'registered_user');
if(isset($_GET['token'])){
    $token = mysqli_real_escape_string($conn,$_GET['token']);
    $query = "select * from password_reset where token='$token'";
    $run = mysqli_query($conn,$query);
    if(mysqli_num_rows($run)>0){
        $row = mysqli_fetch_array($run);
        $token = $row['token'];
        $email = $row['email'];


    }else{
        header("location:login.php");
    }
}


if(isset($_POST['submit'])){
    $password = mysqli_real_escape_string($conn,$_POST['password']);
    $confirmpassword = mysqli_real_escape_string($conn,$_POST['confirmpassword']);
    $options = ['cost'=>11];
    $hashed = password_hash($password,PASSWORD_BCRYPT,$options);
    if($password!=$confirmpassword){
        $msg = "<div class='alert alert-danger'>Sorry,password didnt matched</div>";
    }elseif(strlena($password)<6){
        $msg = "<div class='alert alert-danger'>Password must be 6 characters long</div>";
    }else{
        $query = "update users set password='$hashed'where email='$email'";
        mysqli_query($conn,$query);
        $query = "delete from password_reset where email='$email'";
        mysqli_query($conn,$query);
        $msg = "<div class='alert alert-success'>Password Updated</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" 
    integrity=sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u
    crossorigin="anonymous">
    <link rel="stylesheet" href="/css/main.css">
</head>
<body>

<div class="container">
    <div class="row">
    <div class="col-md-6 col-md-offset-3">
    <h1>Reset Password</h1><hr>
    <form action=""method="post">
    <div class="form-group">
    <label for="">Email</label>
    <input type="text" readonly class="form-control" name=""value="<?php echo$email;?>">
    </div>
    <div class="form-group">
    <label for="">Password</label>
    <input type="password" class="form-control" name="password">
    </div>
    <div class="form-group">
    <label for="">Confirm Password</label>
    <input type="password" class="form-control" name="confirmpassword">
    </div>
    <?php if(isset($msg)){echo $msg;}?>
    <div class="form-group">
    <button name="submit" class="btn btn-primary btn-block">Reset Password</button>
    </div>
    
    </form>
    </div>
    </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7I2mCWNIpG9mGNIcPD7Txa"
        crossorigin="anonymous"></script>
</div>
</body>
</html>