<?php

session_start();
if(isset($_SESSION['username'])){
   
}
?>


<html>
    <head><center>
        <title>Home Page</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    </head>
    <body>
<br><br>
        <div class="container">
        <h1> Welcome </h1><br><br>
        <a class="float-center" href="login_page.php"> LOGOUT </a>

       

</div></center>
    </body>
</html>