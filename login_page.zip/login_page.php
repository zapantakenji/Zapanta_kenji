<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		form{
			margin-left: 400px;
		}
		span{
			text-align: center;
			color: red;
		}
	</style>
	 <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login and Registration</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
</head>
<?php
 

 session_start();
$conn = mysqli_connect("localhost","root",'',"registered_user");

if (isset($_POST['submit'])){
	 $username=$_POST['username'];
	 $password=$_POST['password'];

	 $sql;
	 $check=mysqli_query($conn, "SELECT * from user where username='$username' and password='$password'");

	 if( mysqli_num_rows($check) == 1){
	 	header("Location: home.php");
	}else{
		echo "<center><span>Incorrect Username of Password</span></center>";
	}
}
?>
<body>
	<center>
	<form action="" method="POST">
<div class="container">
    <div class="login-box">
    <div class="row">
    <div class="col-md-6 login-left">
        <h2>Login Here</h2>
        <form action="" method="post">
        <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" class="form-control" required>   
    </div>
    <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" class="form-control" required>   
    </div>
    <button type="submit" class="btn btn-primary" name="submit">Login</button>
</center><br>
	<center><a href="registration_page.php">Click here to Register<a/></center>
</form>
</div>
</body>
</html>