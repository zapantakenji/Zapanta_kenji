<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login and Registration</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
</head>
<style>
body{
	text-align: center;
}
span{
	color:red;
}

</style>
<?php
session_start();
$conn = mysqli_connect("localhost","root","","registered_user");
$correct=1;

if (isset($_POST['register'])){
	$username=$_POST['username'];
	$email=$_POST['email'];
	$password1=$_POST['password1'];
	$password2=$_POST['password2'];



	$check_username=mysqli_query($conn, "SELECT * from user where username='$username'");

	if( mysqli_num_rows($check_username) == 1){
    echo"<span>Username is Already Taken</span>";
    echo "<br>";
	}else{
		$correct+=1;
	}

	$check_email=mysqli_query($conn, "SELECT * from user where email='$email'");
	if( mysqli_num_rows($check_email) == 1){

    echo"<span>Email is Already Taken</span>";
    echo "<br>";
	}else{
			$correct+=1;
	}
	$uppercase = preg_match('@[A-Z]@', $password1);
	$lowercase = preg_match('@[a-z]@', $password1);
	$number    = preg_match('@[0-9]@', $password1);
	$specialChars = preg_match('@[^\w]@', $password1);

	if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password1) < 8) {
    echo '<span>Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.</span>';
    echo "<br>";
	}else{
			$correct+=1;
	}

	if ($password1!==$password2){
		echo"<span>Password does not match</span>";
		echo "<br>";
	}else{
			$correct+=1;
	}
	

	if ($correct==5){
		$sql=mysqli_query($conn, "INSERT into user (username, password, email) values ('$username', '$password1', '$email')");
	
		echo "<script>alert('Successfully Registered')</script>";
	
	}
	
}


?>
<body>
	<center>
	<form action="" method='POST'>
<div class="col-md-6 login-right">
        <h2>Register Here</h2>
        <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" class="form-control" required>   
    	</div>
    	<div class="form-group">
        <label>Email</label>
        <input type="text" name="email" class="form-control" required>   
    	</div>
    <div class="form-group">
        <label>Password</label>
        <input type="password" name="password1" class="form-control" required>   
    </div>
    <div class="form-group">
        <label>Confirm Password</label>
        <input type="password" name="password2" class="form-control" required>   
    	</div>
    <button type="submit" class="btn btn-primary" name="register">Register</button>
</div>
<br>

	<a href="login_page.php">Click here to login<a/>
</form>
</center>


</body>
</html>